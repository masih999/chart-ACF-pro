<?php
namespace FMD\Utilities;

defined('ABSPATH') || exit;

class Data {

    /**
     * Scan all tables like wp_%_logs and return fields.
     * Returns: [ [table => 'wp_x_logs', fields => [col1, col2, ...]], ...]
     */
    public static function scan_tables() {
    global $wpdb;
    $tables = $wpdb->get_col("SHOW TABLES");
    $result = [];
    foreach ($tables as $tbl) {
        // فقط جدول‌هایی که etp در نام دارند
        if (stripos($tbl, 'etp') !== false) {
            $desc = $wpdb->get_results("DESCRIBE `$tbl`");
            $numeric_fields = [];
            foreach ($desc as $field) {
                if (
                    in_array($field->Type, ['int','bigint','float','double','decimal','tinyint','smallint','mediumint'])
                    || preg_match('/(int|float|double|decimal)/', $field->Type)
                ) {
                    $numeric_fields[] = $field->Field;
                }
            }
            if ($numeric_fields) {
                $result[] = ['table' => $tbl, 'fields' => $numeric_fields];
            }
        }
    }
    return $result;
}

    /**
     * Query stats for fields in a table.
     * @param string $table
     * @param array $fields
     * @param string $range Date range, e.g., '2024-01-01..2025-01-01'
     * @param string $type Stat type: sum|avg|distribution
     * @return array
     */
    public static function get_field_stats($table, $fields, $range, $type) {
        global $wpdb;
        $table = esc_sql($table);
        $fields = array_map('esc_sql', $fields);

        // Range parsing
        $where = '';
        if ($range && preg_match('/^\d{4}-\d{2}-\d{2}\.\.\d{4}-\d{2}-\d{2}$/', $range)) {
            [$from, $to] = explode('..', $range);
            $where = "WHERE `created_at` BETWEEN '$from' AND '$to'";
        }

        $result = [
            'labels' => [],
            'datasets' => [],
        ];

        // Example for one field: sum, avg, or group by date
        foreach ($fields as $field) {
            $label = $field;
            switch ($type) {
                case 'avg':
                    $val = $wpdb->get_var("SELECT AVG(`$field`) FROM `$table` $where");
                    $result['labels'][] = $label;
                    $result['datasets'][] = ['label' => $label, 'data' => [floatval($val)]];
                    break;
                case 'distribution':
                    // Group by value
                    $dist = $wpdb->get_results("SELECT `$field` as value, COUNT(*) as count FROM `$table` $where GROUP BY `$field` ORDER BY value");
                    $result['labels'] = array_column($dist, 'value');
                    $result['datasets'][] = ['label' => $label, 'data' => array_column($dist, 'count')];
                    break;
                case 'sum':
                default:
                    $val = $wpdb->get_var("SELECT SUM(`$field`) FROM `$table` $where");
                    $result['labels'][] = $label;
                    $result['datasets'][] = ['label' => $label, 'data' => [floatval($val)]];
                    break;
            }
        }
        return $result;
    }
}