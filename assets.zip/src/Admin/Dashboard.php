<?php
namespace FMD\Admin;

defined('ABSPATH') || exit;

class Dashboard {

    public static function register_menu() {
        if (!current_user_can('view_form_charts')) return;
        add_menu_page(
            __('Form Charts', 'form-metrics-dashboard'),
            __('Form Charts', 'form-metrics-dashboard'),
            'view_form_charts',
            'form-metrics-dashboard',
            [__CLASS__, 'render_screen'],
            'dashicons-chart-bar',
            55
        );
    }

    public static function enqueue_assets($hook) {
    if ($hook !== 'toplevel_page_form-metrics-dashboard') return;

    $assets_url = plugins_url('assets/', dirname(__DIR__, 2) . '/form-metrics-dashboard.php');
    $ver_js = filemtime(dirname(__DIR__, 2) . '/assets/js/dashboard.js');
    $ver_css = filemtime(dirname(__DIR__, 2) . '/assets/css/dashboard.css');
    $ver_chart = filemtime(dirname(__DIR__, 2) . '/assets/js/chart.min.js');

    wp_enqueue_script('fmd-chart', $assets_url . 'js/chart.min.js', [], $ver_chart, true);
    wp_enqueue_script('fmd-datepicker', $assets_url . 'js/persian-datepicker.js', [], null, true);
    wp_enqueue_script('fmd-dashboard', $assets_url . 'js/dashboard.js', ['fmd-chart', 'fmd-datepicker', 'jquery'], $ver_js, true);
    wp_enqueue_style('fmd-dashboard', $assets_url . 'css/dashboard.css', [], $ver_css);

    // متا را اینجا به فرم JS پاس بده
    $tables = \FMD\Utilities\Data::scan_tables();

    wp_localize_script('fmd-dashboard', 'FMD_Settings', [
        'restUrl'   => rest_url('form-metrics/v1/stats'),
        'nonce'     => wp_create_nonce('wp_rest'),
        'canExport' => false,
        'meta'      => [ 'tables' => $tables ]
    ]);
}

    public static function render_screen() {
        if (!current_user_can('view_form_charts')) {
            wp_die(__('You do not have permission to view this page.'));
        }
        ?>
        <div class="fmd-dashboard">
            <h1><?php esc_html_e('Form Metrics Dashboard', 'form-metrics-dashboard'); ?></h1>
            <div id="fmd-dashboard-root"></div>
            <!-- Screen markup is rendered by JS (dashboard.js), minimal PHP HTML here -->
        </div>
        <?php
    }
}