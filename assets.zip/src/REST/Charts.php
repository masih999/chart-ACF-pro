<?php
namespace FMD\REST;

use FMD\Utilities\Data;

defined('ABSPATH') || exit;

class Charts {

    public static function register_routes() {
        register_rest_route('form-metrics/v1', '/stats', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_stats'],
            'args' => [
                'table' => ['required' => true, 'sanitize_callback' => 'sanitize_key'],
                'fields' => ['required' => true],
                'range' => ['required' => false],
                'type' => ['required' => false, 'sanitize_callback' => 'sanitize_key'],
            ],
            'permission_callback' => [__CLASS__, 'check_permissions'],
        ]);
    }

    public static function check_permissions() {
        return current_user_can('view_form_charts') && wp_verify_nonce($_REQUEST['_wpnonce'] ?? '', 'wp_rest');
    }

    public static function get_stats($request) {
        $ip = $_SERVER['REMOTE_ADDR'];
        $key = 'fmd_rate_' . md5($ip);
        $limit = 30;
        $window = 5 * MINUTE_IN_SECONDS;

        $count = (int) get_transient($key);
        if ($count >= $limit) {
            return new \WP_Error('rate_limited', 'Rate limit exceeded', ['status' => 429]);
        }
        set_transient($key, $count + 1, $window);

        $table = sanitize_key($request->get_param('table'));
        $fields = (array) $request->get_param('fields');
        $fields = array_map('sanitize_key', $fields);

        $range = sanitize_text_field($request->get_param('range'));
        $type = sanitize_key($request->get_param('type'));

        $cache_key = 'fmd_stats_' . md5($table . serialize($fields) . $range . $type);
        $cached = get_transient($cache_key);
        if ($cached) return $cached;

        // Query data
        $data = Data::get_field_stats($table, $fields, $range, $type);

        set_transient($cache_key, $data, 300);
        return $data;
    }
}