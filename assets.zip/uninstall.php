<?php
// Uninstall script for Form Metrics Dashboard
if (!defined('WP_UNINSTALL_PLUGIN')) exit;

// Clean up transients if user opts in via a constant
if (defined('FMD_DELETE_TRANSIENTS_ON_UNINSTALL') && FMD_DELETE_TRANSIENTS_ON_UNINSTALL) {
    global $wpdb;
    $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_fmd_%' OR option_name LIKE '_transient_timeout_fmd_%'");
}