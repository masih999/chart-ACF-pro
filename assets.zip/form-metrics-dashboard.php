<?php
/**
 * Plugin Name: Form Metrics Dashboard
 * Description: نمایش داشبورد نمودار برای فرم‌های ACF Pro بدون وابستگی خارجی (Chart.js باندل شده است).
 * Version: 1.0.0
 * Author: masih999
 * Requires at least: 6.2
 * Tested up to: 6.8
 * Requires PHP: 7.4
 * Text Domain: form-metrics-dashboard
 */

defined('ABSPATH') || exit;

// Minimum requirements
define('FMD_PHP_REQUIRED', '7.4');
define('FMD_WP_REQUIRED', '6.2');
define('FMD_ACF_REQUIRED', '6.0');
define('FMD_VERSION', '1.0.0');

// Check PHP, WP, ACF Pro
register_activation_hook(__FILE__, function () {
    if (version_compare(PHP_VERSION, FMD_PHP_REQUIRED, '<')) {
        wp_die('Form Metrics Dashboard: PHP '.FMD_PHP_REQUIRED.'+ required.');
    }
    global $wp_version;
    if (version_compare($wp_version, FMD_WP_REQUIRED, '<')) {
        wp_die('Form Metrics Dashboard: WP '.FMD_WP_REQUIRED.'+ required.');
    }
    if (!class_exists('ACF')) {
        wp_die('Form Metrics Dashboard: ACF Pro required.');
    }
});

// Custom capability
register_activation_hook(__FILE__, function () {
    $role = get_role('administrator');
    if ($role && !$role->has_cap('view_form_charts')) {
        $role->add_cap('view_form_charts');
    }
});
register_deactivation_hook(__FILE__, function () {
    $role = get_role('administrator');
    if ($role && $role->has_cap('view_form_charts')) {
        $role->remove_cap('view_form_charts');
    }
});

// Autoload (PSR-4 simple)
spl_autoload_register(function ($class) {
    if (strpos($class, 'FMD\\') === 0) {
        $file = __DIR__ . '/src/' . str_replace('\\', '/', substr($class, 4)) . '.php';
        if (file_exists($file)) require_once $file;
    }
});

// Hooks
add_action('admin_menu', ['FMD\\Admin\\Dashboard', 'register_menu']);
add_action('admin_enqueue_scripts', ['FMD\\Admin\\Dashboard', 'enqueue_assets']);
add_action('rest_api_init', ['FMD\\REST\\Charts', 'register_routes']);

// Optional: uninstall.php for transient cleanup
