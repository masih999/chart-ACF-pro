=== Form Metrics Dashboard ===
Contributors: masih999
Tags: acf, charts, dashboard, analytics, forms, statistics
Requires at least: 6.2
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

A lightweight, dependency-free dashboard for visualizing ACF Pro form submissions using Chart.js (bundled), with support for Line, Bar, Pie, Doughnut, Radar, Polar Area, and Scatter charts.

== Description ==

**Form Metrics Dashboard** scans your ACF Pro form submission tables (like `wp_%_logs`) for numeric fields and lets you build custom visual dashboards with any chart type — using only WordPress core and its own static assets (no Composer, no external dependencies). Data queries are RESTful, rate-limited, and cached for high performance.

- Visualize form data with Line, Bar, Pie, Doughnut, Radar, Polar Area, Scatter charts (Chart.js 4 bundled)
- No external PHP/JS/CSS dependencies (all static assets are inside plugin)
- Top-level admin menu for users with `view_form_charts` capability
- Dynamic dashboard: add/remove/refresh widgets, drag-and-drop grid layout (CSS only)
- Data source: auto-detects all `wp_%_logs` tables with numeric fields
- REST API endpoint with nonce, caching, and rate limits
- Persian (Jalali) datepicker bundled
- All queries and outputs sanitized and escaped (WordPress-VIP PHPCS compliant)
- Optional uninstall script to remove all plugin transients

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/form-metrics-dashboard/`
2. Activate via Plugins menu.
3. Requires PHP 7.4+, WP 6.2+, and ACF Pro.
4. Go to **Form Charts** in admin menu.

== FAQ ==

= Does it support multisite? =
Not yet (planned).

= Can I export chart PNGs or save widget layouts? =
Not yet — code is scaffolded for future features.

= Is my data private and secure? =
Yes. All endpoints require a capability and a nonce, and all outputs/inputs are sanitized.

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
First stable release.

== License ==

GPLv2 or later.