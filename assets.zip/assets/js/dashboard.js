// Form Metrics Dashboard - JS (vanilla, no React, no jQuery except for select2 if used)
document.addEventListener('DOMContentLoaded', function () {
    const root = document.getElementById('fmd-dashboard-root');
    if (!root) return;

    // Fetch tables and fields metadata
    let meta = {};

function fetchMeta() {
    if (window.FMD_Settings && window.FMD_Settings.meta) {
        meta = window.FMD_Settings.meta;
        renderFilter();
    } else {
        root.innerHTML = "Loading meta...";
    }
}

    // Render filter form
    function renderFilter() {
        root.innerHTML = `
        <form id="fmd-form">
            <label>Table
                <select id="fmd-table">
                    <option value="">--</option>
                    ${meta.tables.map(t => `<option value="${t.table}">${t.table}</option>`).join('')}
                </select>
            </label>
            <label>Fields
                <select id="fmd-fields" multiple></select>
            </label>
            <label>Date Range
                <input type="text" id="fmd-range" placeholder="YYYY-MM-DD..YYYY-MM-DD">
            </label>
            <label>Chart Type
                <select id="fmd-type">
                    <option value="line">Line</option>
                    <option value="bar">Bar</option>
                    <option value="pie">Pie</option>
                    <option value="doughnut">Doughnut</option>
                    <option value="radar">Radar</option>
                    <option value="polarArea">Polar Area</option>
                    <option value="scatter">Scatter</option>
                </select>
            </label>
            <button type="submit">+ Add Widget</button>
        </form>
        <div id="fmd-widget-grid" class="fmd-grid"></div>
        `;
        document.getElementById('fmd-table').addEventListener('change', function () {
            const tbl = this.value;
            const fld = meta.tables.find(t => t.table === tbl);
            let html = '';
            if (fld) {
                html = fld.fields.map(f => `<option value="${f}">${f}</option>`).join('');
            }
            document.getElementById('fmd-fields').innerHTML = html;
        });
        document.getElementById('fmd-form').addEventListener('submit', function (e) {
            e.preventDefault();
            addWidget();
        });
    }

    // Add widget to grid
    function addWidget() {
        const tbl = document.getElementById('fmd-table').value;
        const flds = Array.from(document.getElementById('fmd-fields').selectedOptions).map(o => o.value);
        const range = document.getElementById('fmd-range').value;
        const type = document.getElementById('fmd-type').value;
        if (!tbl || !flds.length) return alert('Select table and field(s).');

        const grid = document.getElementById('fmd-widget-grid');
        const id = 'wid_' + Math.random().toString(36).slice(2, 9);

        const widget = document.createElement('div');
        widget.className = 'fmd-widget';
        widget.id = id;
        widget.innerHTML = `
            <div class="fmd-widget-header">
                <strong>${tbl} - ${flds.join(',')}</strong>
                <button type="button" class="fmd-refresh">⟳</button>
                <button type="button" class="fmd-remove">✖</button>
            </div>
            <canvas></canvas>
        `;
        grid.appendChild(widget);

        widget.querySelector('.fmd-refresh').addEventListener('click', () => loadChart(widget, tbl, flds, range, type));
        widget.querySelector('.fmd-remove').addEventListener('click', () => widget.remove());

        loadChart(widget, tbl, flds, range, type);
    }

    // Load chart data via REST
    function loadChart(widget, table, fields, range, type) {
        const canvas = widget.querySelector('canvas');
        canvas.height = 300;
        widget.classList.add('loading');
        fetch(`${FMD_Settings.restUrl}?table=${encodeURIComponent(table)}&fields[]=${fields.map(encodeURIComponent).join('&fields[]=')}&range=${encodeURIComponent(range)}&type=${encodeURIComponent(type)}&_wpnonce=${FMD_Settings.nonce}`)
            .then(r => r.json())
            .then(data => {
                widget.classList.remove('loading');
                if (data.code) {
                    canvas.replaceWith(document.createTextNode(data.message));
                    return;
                }
                new Chart(canvas, {
                    type: type,
                    data: data,
                    options: {}
                });
            });
    }

    fetchMeta();
});